import 'package:flutter/material.dart';
import 'package:plant_app/pages/onBoarding/on_boarding.dart';
import 'package:plant_app/pages/root.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

bool? isOnBoardinPageWatched = false;

save(bool value) async {
  SharedPreferences pref = await SharedPreferences.getInstance();
  await pref.setBool('isOnboardingPageWatched', value);
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  load(String key) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    setState(() {
      isOnBoardinPageWatched = pref.getBool(key);
    });
  }

  @override
  void initState() {
    load('isOnboardingPageWatched');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Plant App',
      debugShowCheckedModeBanner: false,
      home: isOnBoardinPageWatched != null && isOnBoardinPageWatched == true
          ? const RootPage()
          : const OnBoarding(),
    );
  }
}
