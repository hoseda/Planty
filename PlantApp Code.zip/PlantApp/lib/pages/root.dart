import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:plant_app/const/constants.dart';
import 'package:plant_app/model/model.dart';
import 'package:plant_app/pages/cart.dart';
import 'package:plant_app/pages/favorite_page.dart';
import 'package:plant_app/pages/home_page.dart';
import 'package:plant_app/pages/profile.dart';
import 'package:plant_app/pages/camera/scan_page.dart';

class RootPage extends StatefulWidget {
  const RootPage({
    super.key,
  });

  @override
  State<RootPage> createState() => _HomePageState();
}

class _HomePageState extends State<RootPage> {
  int bottomindex = 0;

  List<String> appBartitleName = const [
    'خانه',
    'علاقه‌مندی‌ها',
    'سبد‌خرید',
    'پروفایل',
  ];

  List<IconData> navBarIcons = [
    Icons.home_rounded,
    Icons.favorite_rounded,
    Icons.shopping_cart_rounded,
    Icons.person_rounded,
  ];

  List<Plant> favorits = [];
  List<Plant> cards = [];

  List<Widget> pages() {
    return [
      const HomePage(),
      FavoritePage(favorits: favorits),
      CartPage(cards: cards),
      const ProfilePage(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const Icon(
          Icons.notifications,
          color: Colors.grey,
          size: 34,
        ),
        elevation: 0,
        backgroundColor: Colors.white,
        actions: [
          Center(
            child: Text(
              appBartitleName[bottomindex],
              style: const TextStyle(
                color: Colors.grey,
                fontSize: 26,
                fontFamily: 'Lalezar',
              ),
            ),
          ),
          const SizedBox(
            width: 20,
          )
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            PageTransition(
              child: const ScanPage(),
              type: PageTransitionType.fade,
            ),
          );
        },
        backgroundColor: Constants.primaryColor,
        focusColor: Colors.grey,
        child: const Icon(
          Icons.qr_code_scanner_rounded,
          size: 35,
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      body: IndexedStack(
        index: bottomindex,
        children: pages(),
      ),
      bottomNavigationBar: AnimatedBottomNavigationBar(
        icons: navBarIcons,
        height: 60,
        activeIndex: bottomindex,
        gapLocation: GapLocation.center,
        splashColor: Constants.primaryColor,
        activeColor: Constants.primaryColor,
        inactiveColor: Constants.blackColor,
        onTap: (index) {
          setState(() {
            bottomindex = index;

            List<Plant> addFavorits =
                Plant.getFavoritedPlants().toSet().toList();
            List<Plant> addCards = Plant.addedToCartPlants().toSet().toList();

            favorits = addFavorits;
            cards = addCards;
          });
        },
      ),
    );
  }
}
