import 'package:flutter/material.dart';
import 'package:plant_app/const/constants.dart';
import 'package:plant_app/model/model.dart';
import 'package:plant_app/pages/home_page.dart' show FarsiNumberExtension;

class DetailPage extends StatefulWidget {
  final Plant plant;
  const DetailPage({
    super.key,
    required this.plant,
  });

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  bool _ = false;
  List<Plant> get getCards {
    List<Plant> cards = Plant.addedToCartPlants().toSet().toList();
    return cards;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Positioned(
              top: 20,
              left: 20,
              right: 20,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: Constants.primaryColor.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: Icon(
                        Icons.close_rounded,
                        color: Constants.primaryColor,
                      ),
                    ),
                  ),
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Constants.primaryColor.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Icon(
                      widget.plant.isFavorated
                          ? Icons.favorite
                          : Icons.favorite_border,
                      color: Constants.primaryColor,
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: 110,
              left: 40,
              child: SizedBox(
                height: 340,
                child: Image.asset(widget.plant.imageURL),
              ),
            ),
            Positioned(
              top: 110,
              right: 40,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    'اندازه‌گیاه',
                    style: TextStyle(
                      fontFamily: 'Lalezar',
                      color: Constants.blackColor,
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    widget.plant.size,
                    style: TextStyle(
                      fontFamily: 'Lalezar',
                      color: Constants.primaryColor,
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    'رطوبت‌هوا',
                    style: TextStyle(
                      fontFamily: 'Lalezar',
                      color: Constants.blackColor,
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    widget.plant.humidity.toString().farsiNumber,
                    style: TextStyle(
                      fontFamily: 'Lalezar',
                      color: Constants.primaryColor,
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    'دمای‌نهگداری',
                    style: TextStyle(
                      fontFamily: 'Lalezar',
                      color: Constants.blackColor,
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    widget.plant.temperature.farsiNumber,
                    style: TextStyle(
                      fontFamily: 'Lalezar',
                      color: Constants.primaryColor,
                      fontSize: 20,
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                height: 475,
                decoration: BoxDecoration(
                  color: Constants.primaryColor.withAlpha(100),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 93,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          widget.plant.plantName,
                          style: TextStyle(
                            fontFamily: 'Lalezar',
                            fontSize: 29,
                            color: Constants.primaryColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(
                          width: 30,
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 30.0,
                        vertical: 13,
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.star,
                            color: Constants.primaryColor,
                            size: 30,
                          ),
                          Text(
                            widget.plant.rating.toString().farsiNumber,
                            style: TextStyle(
                              fontFamily: 'Lalezar',
                              fontSize: 25,
                              color: Constants.primaryColor,
                            ),
                          ),
                          const Spacer(),
                          SizedBox(
                            width: 30,
                            child: Image.asset(
                                'assets/images/PriceUnit-green.png'),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          Text(
                            widget.plant.price.toString().farsiNumber,
                            style: TextStyle(
                              fontFamily: 'Lalezar',
                              fontSize: 30,
                              color: Constants.blackColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 30.0),
                      child: Text(
                        widget.plant.decription,
                        // textAlign: TextAlign.justify,
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontFamily: 'iranSans',
                          color: Constants.blackColor,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              bottom: 20,
              left: 25,
              right: 25,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (context) => CartPage(cards: getCards),
                      //   ),
                      // );
                    },
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: Constants.primaryColor.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: const Icon(
                            Icons.shopping_cart,
                            color: Colors.white,
                          ),
                        ),
                        Visibility(
                          visible: widget.plant.isSelected ? true : false,
                          child: Positioned(
                            right: 3,
                            top: 1,
                            child: Container(
                              width: 9,
                              height: 9,
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 211, 0, 0),
                                borderRadius: BorderRadius.circular(50),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.2),
                                    offset: const Offset(-1, 3),
                                    blurRadius: 0.8,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      if (_ == false && widget.plant.isSelected == false) {
                        setState(() {
                          widget.plant.isSelected = true;
                          _ = true;
                        });
                      }

                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          behavior: SnackBarBehavior.floating,
                          duration: const Duration(seconds: 1),
                          showCloseIcon: true,
                          closeIconColor: Colors.white,
                          dismissDirection: DismissDirection.horizontal,
                          margin: const EdgeInsets.only(
                            bottom: 100,
                            left: 20,
                            right: 20,
                          ),
                          content: Directionality(
                            textDirection: TextDirection.rtl,
                            child: Center(
                              child: Text(
                                !_
                                    ? '${widget.plant.plantName} در سبد خرید وجود دارد.'
                                    : '${widget.plant.plantName} به سبد خریداضافه شد.',
                                style: const TextStyle(
                                  fontFamily: 'iranSans',
                                  fontSize: 20,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Constants.primaryColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      minimumSize: const Size(280, 55),
                      maximumSize: const Size(280, 55),
                    ),
                    child: const Text(
                      'افزودن به سبد خرید',
                      style: TextStyle(
                        fontFamily: 'Lalezar',
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
