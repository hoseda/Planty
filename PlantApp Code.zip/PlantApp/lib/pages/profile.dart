import 'package:flutter/material.dart';
import 'package:plant_app/const/constants.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  List<String> itemsName = [
    'پروفایل‌من',
    'تنظیمات',
    'اطلاع‌رسانی‌ها',
    'شبکه‌های‌اجتماعی',
    'خروج',
  ];

  List<IconData> itemsIcon = [
    Icons.person,
    Icons.settings,
    Icons.notifications,
    Icons.share,
    Icons.exit_to_app_rounded,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 145,
                    width: 145,
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Constants.primaryColor.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(100),
                    ),
                    child: const CircleAvatar(
                      backgroundImage:
                          ExactAssetImage('assets/images/profile.jpg'),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Directionality(
                textDirection: TextDirection.rtl,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 27,
                      child: Image.asset('assets/images/verified.png'),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Text(
                      'ساناز‌ امینی',
                      style: TextStyle(
                        fontFamily: 'iranSans',
                        fontSize: 20,
                        color: Constants.blackColor,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              Text(
                'Moallemi@gmail.com',
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.grey.shade500,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              Expanded(
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: ListView.builder(
                    itemCount: itemsName.length,
                    physics: const BouncingScrollPhysics(
                      decelerationRate: ScrollDecelerationRate.fast,
                    ),
                    scrollDirection: Axis.vertical,
                    reverse: false,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        child: ListTile(
                          leading: Icon(itemsIcon[index]),
                          minLeadingWidth: 10,
                          title: Text(
                            itemsName[index],
                            style: TextStyle(
                              fontFamily: 'iranSans',
                              fontSize: 20,
                              color: Constants.blackColor,
                            ),
                          ),
                          trailing:
                              const Icon(Icons.arrow_back_ios_new_rounded),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
