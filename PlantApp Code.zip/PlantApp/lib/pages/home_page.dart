import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:plant_app/const/constants.dart';
import 'package:plant_app/model/model.dart';
import 'package:plant_app/pages/detail_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final SearchController controller = SearchController();
  List<Plant> plantList = Plant.plantList;

  //category

  int selectedIndex = 0;
  final List<String> _category = [
    'همه',
    'پیشنهادی',
    'آپارتمانی',
    'محل‌کار',
    'باغچه‌ایی',
  ];

  List<Plant> _filtering(String category) {
    if (category == 'همه') {
      return plantList;
    } else {
      var plants = plantList.where((element) => element.category == category);
      return plants.toList();
    }
  }

  // Searching

  List<String> _results = [];

  List<String> get generateList {
    List<String> _ = [];
    List.generate(
        plantList.length, (index) => _.add(plantList[index].plantName));
    return _;
  }

  void _handleSearch(String input) {
    _results.clear();
    for (var item in plantList) {
      if (item.plantName.toLowerCase().contains(input.toLowerCase())) {
        setState(() {
          _results.add(item.plantName);
        });
      }
    }
  }

  @override
  void initState() {
    controller.addListener(searchListner);
    super.initState();
  }

  void search(String text) {
    if (text.isEmpty) {
      _results = generateList;
    } else {
      _handleSearch(text);
    }
  }

  void searchListner() {
    search(controller.text);
  }

  @override
  void dispose() {
    controller.removeListener(searchListner);
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            children: [
              const SizedBox(
                height: 3,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 15.0,
                  vertical: 5,
                ),
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: SearchAnchor(
                    searchController: controller,
                    isFullScreen: true,
                    viewHintText: 'جستوجو ....',
                    headerHintStyle: const TextStyle(
                      fontFamily: 'iranSans',
                      color: Colors.grey,
                      fontSize: 14,
                    ),
                    headerTextStyle: TextStyle(
                      fontFamily: 'iranSans',
                      fontSize: 15,
                      color: Constants.blackColor,
                    ),
                    viewLeading: Padding(
                      padding: const EdgeInsets.only(right: 5),
                      child: GestureDetector(
                        onTap: () => controller.closeView(controller.text),
                        child: Icon(
                          Icons.search_rounded,
                          color: Constants.blackColor,
                          size: 30,
                        ),
                      ),
                    ),
                    viewTrailing: [
                      Padding(
                        padding: const EdgeInsets.only(left: 5),
                        child: Icon(
                          Icons.keyboard_voice_rounded,
                          color: Constants.blackColor,
                          size: 30,
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          controller.clear();
                          controller.closeView(controller.text);
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: Icon(
                            Icons.close,
                            color: Constants.blackColor,
                            size: 30,
                          ),
                        ),
                      ),
                    ],
                    builder: (context, controller) {
                      return SearchBarTheme(
                        data: SearchBarThemeData(
                          elevation: MaterialStateProperty.all<double?>(0),
                          padding: MaterialStateProperty.all(
                            const EdgeInsets.all(7),
                          ),
                          backgroundColor: MaterialStateProperty.all<Color?>(
                            const Color(0xFFe5ece8),
                          ),
                          overlayColor:
                              MaterialStateProperty.all(Colors.transparent),
                          shape: MaterialStateProperty.all<OutlinedBorder?>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18),
                            ),
                          ),
                          constraints: const BoxConstraints(
                            minHeight: 53,
                            maxHeight: 53,
                          ),
                          hintStyle: MaterialStateProperty.all(
                            const TextStyle(
                              fontFamily: 'iranSans',
                              color: Colors.grey,
                              fontSize: 14,
                            ),
                          ),
                          textStyle: MaterialStateProperty.all(
                            TextStyle(
                              fontFamily: 'iranSans',
                              fontSize: 15,
                              color: Constants.blackColor,
                            ),
                          ),
                        ),
                        child: SearchBar(
                          controller: controller,
                          onTap: () => controller.openView(),
                          hintText: 'جستوجو ....',
                          leading: Padding(
                            padding: const EdgeInsets.only(right: 5),
                            child: Icon(
                              Icons.search_rounded,
                              color: Constants.blackColor,
                              size: 30,
                            ),
                          ),
                          trailing: [
                            Padding(
                              padding: const EdgeInsets.only(left: 5),
                              child: Icon(
                                Icons.keyboard_voice_rounded,
                                color: Constants.blackColor,
                                size: 30,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                    suggestionsBuilder: (context, controller) {
                      return [
                        ListView.builder(
                          itemCount: _results.length,
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          reverse: false,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 5,
                                vertical: 5,
                              ),
                              child: GestureDetector(
                                onTap: () {
                                  Plant plant = plantList.firstWhere(
                                    (element) =>
                                        element.plantName == _results[index],
                                  );
                                  Navigator.push(
                                    context,
                                    PageTransition(
                                      child: DetailPage(plant: plant),
                                      type: PageTransitionType.fade,
                                    ),
                                  );
                                },
                                child: ListTile(
                                  title: Text(
                                    _results[index],
                                    style: TextStyle(
                                      fontFamily: 'iranSans',
                                      fontSize: 17,
                                      color: Constants.blackColor,
                                    ),
                                  ),
                                  trailing: const Icon(
                                      Icons.arrow_back_ios_new_rounded),
                                ),
                              ),
                            );
                          },
                        )
                      ];
                    },
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(4),
                child: SizedBox(
                  height: 40,
                  child: ListView.builder(
                    itemCount: _category.length,
                    physics: const BouncingScrollPhysics(
                      decelerationRate: ScrollDecelerationRate.fast,
                    ),
                    reverse: true,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedIndex = index;
                            });
                          },
                          child: Text(
                            '| ${_category[index]} |',
                            style: TextStyle(
                              fontFamily: 'iranSans',
                              fontSize: 18,
                              color: selectedIndex == index
                                  ? Constants.primaryColor
                                  : Constants.blackColor,
                              fontWeight: selectedIndex == index
                                  ? FontWeight.bold
                                  : null,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),

              // product lits
              SizedBox(
                height: 280,
                child: ListView.builder(
                  itemCount: _filtering(_category[selectedIndex]).length,
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(
                    decelerationRate: ScrollDecelerationRate.fast,
                  ),
                  reverse: true,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 10,
                        horizontal: 20,
                      ),
                      child: GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            PageTransition(
                              child: DetailPage(
                                  plant: _filtering(
                                      _category[selectedIndex])[index]),
                              type: PageTransitionType.fade,
                            ),
                          );
                        },
                        child: Container(
                          width: 210,
                          height: 280,
                          decoration: BoxDecoration(
                            color: Constants.primaryColor.withOpacity(0.8),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Stack(
                            children: [
                              Positioned(
                                top: 13,
                                right: 13,
                                child: GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      _filtering(
                                              _category[selectedIndex])[index]
                                          .isFavorated = !_filtering(
                                              _category[selectedIndex])[index]
                                          .isFavorated;
                                    });
                                  },
                                  child: Container(
                                    width: 35,
                                    height: 35,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(50),
                                    ),
                                    child: Icon(
                                      _filtering(_category[selectedIndex])[
                                                  index]
                                              .isFavorated
                                          ? Icons.favorite
                                          : Icons.favorite_border,
                                      color: Constants.primaryColor,
                                      size: 23,
                                    ),
                                  ),
                                ),
                              ),
                              Center(
                                child: SizedBox(
                                  width: 89,
                                  height: 160,
                                  child: Image.asset(
                                    _filtering(_category[selectedIndex])[index]
                                        .imageURL,
                                  ),
                                ),
                              ),
                              Positioned(
                                bottom: 15,
                                right: 20,
                                child: Column(
                                  children: [
                                    Text(
                                      _filtering(
                                              _category[selectedIndex])[index]
                                          .category,
                                      style: const TextStyle(
                                        fontFamily: 'iranSans',
                                        color: Colors.white,
                                        fontWeight: FontWeight.w300,
                                      ),
                                    ),
                                    Text(
                                      _filtering(
                                              _category[selectedIndex])[index]
                                          .plantName,
                                      style: const TextStyle(
                                        fontFamily: 'iranSans',
                                        color: Colors.white,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Positioned(
                                bottom: 15,
                                left: 20,
                                child: Container(
                                  width: 43,
                                  height: 25,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                  child: Text(
                                    '\$${_filtering(_category[selectedIndex])[index].price}',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Constants.primaryColor,
                                      fontSize: 16,
                                      fontFamily: 'iranSans',
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(
                  vertical: 10,
                  horizontal: 15,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      'گیاهان‌ جدید',
                      style: TextStyle(
                        fontFamily: 'Lalezar',
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                  ],
                ),
              ),

              // new product list
              Expanded(
                child: ListView.builder(
                  itemCount: plantList.length,
                  physics: const BouncingScrollPhysics(
                    decelerationRate: ScrollDecelerationRate.fast,
                  ),
                  reverse: false,
                  scrollDirection: Axis.vertical,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 20,
                      ),
                      child: GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            PageTransition(
                              child: DetailPage(plant: plantList[index]),
                              type: PageTransitionType.fade,
                            ),
                          );
                        },
                        child: Container(
                          height: 90,
                          decoration: BoxDecoration(
                            color: Constants.primaryColor.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Directionality(
                            textDirection: TextDirection.rtl,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Align(
                                      alignment: Alignment.bottomRight,
                                      child: Container(
                                        width: 75,
                                        height: 75,
                                        margin: const EdgeInsets.all(3),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(50),
                                          color: Constants.primaryColor
                                              .withOpacity(0.8),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 10,
                                      child: SizedBox(
                                        height: 100,
                                        width: 90,
                                        child: Image.asset(
                                            plantList[index].imageURL),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  width: 15,
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      plantList[index].category,
                                      style: TextStyle(
                                        fontFamily: 'Lalezar',
                                        color: Constants.blackColor,
                                        fontWeight: FontWeight.w300,
                                        fontSize: 15,
                                      ),
                                    ),
                                    Text(
                                      plantList[index].plantName,
                                      style: TextStyle(
                                        fontFamily: 'iranSans',
                                        color: Constants.blackColor,
                                        fontWeight: FontWeight.w500,
                                        fontSize: 17,
                                      ),
                                    ),
                                  ],
                                ),
                                const Spacer(),
                                Text(
                                  plantList[index].price.toString().farsiNumber,
                                  style: TextStyle(
                                    fontFamily: 'Lalezar',
                                    color: Constants.primaryColor,
                                    fontSize: 23,
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                SizedBox(
                                  width: 45,
                                  child: Image.asset(
                                      'assets/images/PriceUnit-green.png'),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

extension FarsiNumberExtension on String {
  String get farsiNumber {
    const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const farsi = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    String text = this;
    for (int i = 0; i < english.length; i++) {
      text = text.replaceAll(english[i], farsi[i]);
    }
    return text;
  }
}
